HSLoader
===================
HSLoader は HeapStats のスナップショットを Elasticsearch にロードするための
アプリケーションです。

# 依存ライブラリ
以下をすべて`<HSLoaderのインストールディレクトリ>/lib`にコピーしてください。
* [HeapStatsFXAnalyzer](https://github.com/YaSuenag/HeapStatsFXAnalyzer)
  * 本リポジトリにJARを登録しています
* [Jackson](http://mvnrepository.com/artifact/com.fasterxml.jackson.core)
  * jackson-core
  * jackson-databind
  * jackson-annotations
* [Elasticsearch](https://www.elastic.co/downloads/elasticsearch)
  * lucene-core
  * elasticsearch

# 使用方法
```
$ java -jar hsloader.jar [options] snapshot1 snapshot2 ...
```

# オプション
* -help
  * ヘルプメッセージ
* -h
  * Elasticsearchのホスト名
  * デフォルト値はlocalhost
* -p
  * Elasticsearchのポート番号
  * デフォルト値は9300
* -b
  * 一度に投入するデータ量（バルク転送）
  * デフォルト値は10
* -z
  * スナップショット取得時間のタイムゾーン指定
  * デフォルトはシステムのタイムゾーン

------------

HSLoader is a software to load HeapStats SnapShot to Elasticsearch.

# Library dependencies
You have to copy all libraries as below to `<Install directory of HSLoader>/lib`:
* [HeapStatsFXAnalyzer](https://github.com/YaSuenag/HeapStatsFXAnalyzer)
  * It is containes in this repository.
* [Jackson](http://mvnrepository.com/artifact/com.fasterxml.jackson.core)
  * jackson-core
  * jackson-databind
  * jackson-annotations
* [Elasticsearch](https://www.elastic.co/downloads/elasticsearch)
  * lucene-core
  * elasticsearch

# How to use
```
$ java -jar hsloader.jar [options] snapshot1 snapshot2 ...
```

# Options
* -help
  * Help message.
* -h
  * Host name of Elasticsearch.
  * Default value is localhost.
* -p
  * Port number of Elasticsearch.
  * Default value is 9300.
* -b
  * Number of bulk requests to Elasticsearch.
  * Default value is 10.
* -z
  * Timezone of SnapShot datetime.
  * Default value is system timezone.
